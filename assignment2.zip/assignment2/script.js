function downloadResume() {
    window.location.href = '/Users/pranay/Desktop/portfolio/Resume_NEU_Pranay.pdf';
}

